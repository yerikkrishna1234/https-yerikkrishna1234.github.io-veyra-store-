# VEYRA static ecommerce starter

A mobile-first static storefront built with plain HTML, CSS and vanilla JavaScript. No npm, framework or build step is required.

## Preview locally
1. Download and unzip the project folder.
2. Open `index.html` in Chrome, Edge, Firefox or Safari.
3. Visit Shop, open a product, add it to your bag, refresh, and confirm the cart persists.
4. Use `cart.html` to change quantities or remove products, then continue to `checkout.html`.

## Files
- `index.html` — home page
- `shop.html` — product catalogue and sorting
- `product.html?id=1` — dynamic product details (IDs 1, 2 and 3)
- `cart.html` — localStorage cart
- `checkout.html` — delivery form, COD/UPI preference and WhatsApp order request
- `about.html`, `contact.html` — brand and support information
- `css/style.css` — mobile-first design system and responsive layouts
- `js/products.js` — all product data in one array
- `js/main.js` — cart, menu, checkout and WhatsApp interactions
- `images/` — local SVG bottle illustrations and UPI placeholder

## Configure before launch
Open `js/main.js` and replace:
- `STORE_WHATSAPP` with the real WhatsApp business number, digits only, including country code (India numbers start with `91`).
- `STORE_EMAIL` with your real business email.
- `UPI_ID` with your verified business UPI ID, if you intend to display it.

Also update the placeholder email and contact text in `contact.html` and `index.html`. Replace `images/upi-qr-placeholder.svg` with a real payment QR only after verifying the UPI details. The included QR graphic is deliberately not a real payment code.

Edit `js/products.js` to update prices, descriptions and product image paths. The current displayed prices (₹799, ₹999 and ₹1,299) are starter examples, not confirmed business prices. No crossed-out sale prices are shown because discounts have not been confirmed. Replace the SVG bottle illustrations with accurate product photos before taking real orders. Confirm supplier specifications, material grade, shipping rates, return policy and warranty terms before launch.

## Important limitations
This is a functional static storefront prototype, not a complete backend ecommerce platform. Cart contents persist in the browser using localStorage. Checkout prepares an order message and opens WhatsApp once a real business number is configured; it does not store orders on a server, reserve stock, send automatic confirmations, charge payments, or verify payment status. UPI is a placeholder display only. Live online payments need a payment gateway and secure integration. Automated order tracking needs a courier/order-management integration. The contact form also prepares a WhatsApp message, not an email transmission.

Google Fonts load over the internet; the site still has system font fallbacks when offline.
