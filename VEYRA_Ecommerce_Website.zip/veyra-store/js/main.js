/* VEYRA storefront interactions — plain JavaScript, no frameworks. */
// Replace these placeholders before launch. WhatsApp must be digits only, including country code.
const STORE_WHATSAPP = "REPLACE_WITH_YOUR_WHATSAPP_NUMBER";
const STORE_EMAIL = "hello@yourdomain.in";
const UPI_ID = "yourname@upi";
const CURRENCY = new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 });

function money(value) { return CURRENCY.format(value); }
function getCart() {
  try { return JSON.parse(localStorage.getItem("veyraCart") || "{}"); }
  catch (error) { return {}; }
}
function saveCart(cart) {
  localStorage.setItem("veyraCart", JSON.stringify(cart));
  updateCartCount();
}
function addToCart(id, quantity = 1) {
  const cart = getCart();
  cart[id] = (Number(cart[id]) || 0) + Math.max(1, Number(quantity) || 1);
  saveCart(cart);
  showToast("Added to your bag");
}
function setQuantity(id, quantity) {
  const cart = getCart();
  if (quantity <= 0) delete cart[id]; else cart[id] = Math.min(99, Math.max(1, Number(quantity) || 1));
  saveCart(cart);
  renderCart();
}
function removeFromCart(id) {
  const cart = getCart(); delete cart[id]; saveCart(cart); renderCart();
}
function cartLines() {
  const cart = getCart();
  return PRODUCTS.filter(p => Number(cart[p.id]) > 0).map(p => ({ ...p, quantity: Number(cart[p.id]), lineTotal: p.price * Number(cart[p.id]) }));
}
function cartSubtotal() { return cartLines().reduce((sum, item) => sum + item.lineTotal, 0); }
function updateCartCount() {
  const count = Object.values(getCart()).reduce((sum, qty) => sum + Number(qty || 0), 0);
  document.querySelectorAll("[data-cart-count]").forEach(el => { el.textContent = count; el.hidden = count === 0; });
}
function showToast(message) {
  let toast = document.querySelector(".toast");
  if (!toast) { toast = document.createElement("div"); toast.className = "toast"; toast.setAttribute("role", "status"); document.body.appendChild(toast); }
  toast.textContent = message; toast.classList.add("is-visible");
  window.clearTimeout(showToast.timer); showToast.timer = window.setTimeout(() => toast.classList.remove("is-visible"), 2200);
}
function productCard(product) {
  const compareMarkup = product.compareAt ? `<del>${money(product.compareAt)}</del>` : "";
  return `<article class="product-card">
    <a class="product-card__image" href="product.html?id=${product.id}" aria-label="View ${product.name}">
      <span class="product-tag">${product.tag}</span><img src="${product.image}" alt="${product.size} ${product.name} copper-finish stainless steel water bottle">
      <span class="image-quick-view">View details <span aria-hidden="true">↗</span></span>
    </a>
    <div class="product-card__body"><div class="product-card__top"><div><p class="eyebrow">${product.size} · STAINLESS STEEL</p><h3><a href="product.html?id=${product.id}">${product.name}</a></h3></div><span class="product-mark" aria-hidden="true">V.</span></div>
      <p class="product-card__description">${product.short}</p><div class="price-row"><strong>${money(product.price)}</strong>${compareMarkup}</div>
      <button class="button button--dark button--full" type="button" data-add="${product.id}">Add to bag <span aria-hidden="true">＋</span></button>
    </div></article>`;
}
function renderProductGrid(target, products = PRODUCTS) {
  const el = document.querySelector(target); if (el) el.innerHTML = products.map(productCard).join("");
}
function renderProductDetail() {
  const target = document.querySelector("[data-product-detail]"); if (!target) return;
  const id = new URLSearchParams(window.location.search).get("id") || "1";
  const p = PRODUCTS.find(item => item.id === id) || PRODUCTS[0];
  document.title = `${p.name} ${p.size} | VEYRA Premium Hydration`;
  const description = document.querySelector('meta[name="description"]'); if (description) description.content = `${p.name}, ${p.size} copper-finish stainless steel bottle from VEYRA. ${p.short}`;
  const compareMarkup = p.compareAt ? `<del>${money(p.compareAt)}</del><span class="save-pill">SAVE ${money(p.compareAt-p.price)}</span>` : "";
  target.innerHTML = `<div class="detail-gallery"><div class="detail-image"><span class="product-tag">${p.tag}</span><img src="${p.image}" alt="${p.size} ${p.name} copper-colour stainless steel water bottle"></div><p class="image-caption">THE VEYRA COLLECTION · COPPER FINISH</p></div>
  <div class="detail-copy"><p class="eyebrow">STAINLESS STEEL · COPPER FINISH</p><h1>${p.name}<span class="heading-period">.</span></h1><p class="detail-size">${p.size} capacity</p><div class="price-row price-row--large"><strong>${money(p.price)}</strong>${compareMarkup}</div><p class="detail-description">${p.description}</p><div class="detail-points"><span><b>01</b> Considered design</span><span><b>02</b> Everyday versatility</span><span><b>03</b> Copper-colour finish</span></div>
  <div class="detail-actions"><label class="quantity-label" for="detail-qty">Qty</label><input id="detail-qty" class="quantity-input" type="number" min="1" max="99" value="1"><button class="button button--copper" type="button" data-add-detail="${p.id}">Add to bag <span aria-hidden="true">↗</span></button></div><p class="fine-print">Product specifications and material grade must be confirmed with the supplier before sale. Product image is a placeholder illustration.</p>
  <div class="accordion-list"><details open><summary>Product details</summary><p>${p.short} Capacity: ${p.capacity}. Finish: ${p.finish}.</p></details><details><summary>Material & care</summary><p>${p.material}. ${p.care}</p></details><details><summary>Shipping & returns</summary><p>Shipping fees, delivery timelines and return eligibility will be confirmed before launch. Please contact our team for help.</p></details></div></div>`;
}
function renderCart() {
  const target = document.querySelector("[data-cart-lines]"); if (!target) return;
  const lines = cartLines();
  const empty = document.querySelector("[data-cart-empty]");
  const content = document.querySelector("[data-cart-content]");
  if (!lines.length) { if (empty) empty.hidden = false; if (content) content.hidden = true; target.innerHTML = ""; updateCartCount(); return; }
  if (empty) empty.hidden = true; if (content) content.hidden = false;
  target.innerHTML = lines.map(item => `<article class="cart-line"><a class="cart-line__image" href="product.html?id=${item.id}"><img src="${item.image}" alt="${item.size} copper-finish stainless steel bottle"></a><div class="cart-line__details"><p class="eyebrow">${item.size} · COPPER FINISH</p><h3><a href="product.html?id=${item.id}">${item.name}</a></h3><p class="cart-line__price">${money(item.price)}</p><div class="cart-line__controls"><label class="sr-only" for="qty-${item.id}">Quantity for ${item.name}</label><input id="qty-${item.id}" class="quantity-input" type="number" min="1" max="99" value="${item.quantity}" data-quantity="${item.id}"><button class="text-button" type="button" data-remove="${item.id}">Remove</button></div></div><strong class="cart-line__total">${money(item.lineTotal)}</strong></article>`).join("");
  const subtotal = cartSubtotal();
  document.querySelectorAll("[data-subtotal]").forEach(el => el.textContent = money(subtotal));
  document.querySelectorAll("[data-cart-total]").forEach(el => el.textContent = money(subtotal));
  updateCartCount();
}
function renderCheckout() {
  const summary = document.querySelector("[data-checkout-summary]"); if (!summary) return;
  const lines = cartLines();
  if (!lines.length) { summary.innerHTML = '<p class="empty-note">Your bag is empty. <a href="shop.html">Explore the collection</a>.</p>'; document.querySelectorAll("[data-checkout-submit]").forEach(btn => btn.disabled = true); return; }
  summary.innerHTML = lines.map(item => `<div class="summary-line"><span>${item.name} <small>× ${item.quantity}</small></span><strong>${money(item.lineTotal)}</strong></div>`).join("") + `<div class="summary-line summary-line--total"><span>Subtotal</span><strong>${money(cartSubtotal())}</strong></div><p class="fine-print">Shipping is confirmed separately before dispatch.</p>`;
  const upi = document.querySelector("[data-upi-id]"); if (upi) upi.textContent = UPI_ID;
}
function openWhatsApp(message) {
  if (!/^\d{10,15}$/.test(STORE_WHATSAPP)) {
    alert("Before launch, open js/main.js and replace STORE_WHATSAPP with your business WhatsApp number, including country code and digits only. Your order details are shown here but have not been sent.");
    return;
  }
  window.open(`https://wa.me/${STORE_WHATSAPP}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}
function bindEvents() {
  document.addEventListener("click", event => {
    const add = event.target.closest("[data-add]");
    if (add) { addToCart(add.dataset.add); return; }
    const addDetail = event.target.closest("[data-add-detail]");
    if (addDetail) { const qty = document.querySelector("#detail-qty"); addToCart(addDetail.dataset.addDetail, qty ? qty.value : 1); return; }
    const remove = event.target.closest("[data-remove]"); if (remove) { removeFromCart(remove.dataset.remove); return; }
    const menu = event.target.closest("[data-menu-toggle]");
    if (menu) { const nav = document.querySelector("[data-mobile-nav]"); const open = menu.getAttribute("aria-expanded") === "true"; menu.setAttribute("aria-expanded", String(!open)); if (nav) nav.classList.toggle("is-open", !open); return; }
    const wa = event.target.closest("[data-whatsapp]");
    if (wa) { event.preventDefault(); openWhatsApp("Hello VEYRA, I have a question about your bottles."); }
  });
  document.addEventListener("change", event => {
    const quantity = event.target.closest("[data-quantity]"); if (quantity) setQuantity(quantity.dataset.quantity, Number(quantity.value));
  });
  const form = document.querySelector("[data-checkout-form]");
  if (form) form.addEventListener("submit", event => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    const data = new FormData(form); const lines = cartLines();
    if (!lines.length) { alert("Your bag is empty. Add a bottle before checking out."); return; }
    const order = lines.map(item => `• ${item.name} (${item.size}) × ${item.quantity} — ${money(item.lineTotal)}`).join("\n");
    const message = `Hello VEYRA, I'd like to place an order.\n\nCUSTOMER\nName: ${data.get("name")}\nPhone: ${data.get("phone")}\nAddress: ${data.get("address")}\n\nORDER\n${order}\n\nSubtotal: ${money(cartSubtotal())}\nPayment preference: ${data.get("payment")}\n\nPlease confirm availability, shipping charges and final order total.`;
    openWhatsApp(message);
  });
  const contactForm = document.querySelector("[data-contact-form]");
  if (contactForm) contactForm.addEventListener("submit", event => { event.preventDefault(); const data = new FormData(contactForm); const message = `Hello VEYRA,\nName: ${data.get("name")}\nEmail: ${data.get("email")}\nMessage: ${data.get("message")}`; openWhatsApp(message); });
}
document.addEventListener("DOMContentLoaded", () => {
  renderProductGrid("[data-featured-products]", PRODUCTS.slice(0, 3));
  renderProductGrid("[data-shop-products]", PRODUCTS);
  renderProductDetail(); renderCart(); renderCheckout(); updateCartCount(); bindEvents();
  const year = document.querySelector("[data-year]"); if (year) year.textContent = new Date().getFullYear();
});
