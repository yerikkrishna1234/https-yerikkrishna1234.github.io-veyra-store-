/* VEYRA product catalogue. Edit names, prices, descriptions and image paths here. */
const PRODUCTS = [
  {
    id: "1", name: "VEYRA Mini", size: "250 ml", price: 799, compareAt: null,
    short: "A compact companion for lighter days.",
    description: "A refined, compact stainless steel bottle for short outings, desk-side hydration and everyday carry. The copper-colour finish pairs with VEYRA's understated premium look.",
    material: "Stainless steel (confirm grade with supplier before launch)", finish: "Copper-colour finish", capacity: "250 ml", care: "Hand-wash recommended until supplier care instructions are confirmed.", image: "images/bottle-250.svg", tag: "COMPACT"
  },
  {
    id: "2", name: "VEYRA Everyday", size: "500 ml", price: 999, compareAt: null,
    short: "Your everyday bottle, elevated.",
    description: "A balanced everyday size for commutes, classes, office hours and weekend plans. Its copper-colour stainless steel look brings a warm accent to a clean, modern silhouette.",
    material: "Stainless steel (confirm grade with supplier before launch)", finish: "Copper-colour finish", capacity: "500 ml", care: "Hand-wash recommended until supplier care instructions are confirmed.", image: "images/bottle-500.svg", tag: "BESTSELLER"
  },
  {
    id: "3", name: "VEYRA Explore", size: "1 litre", price: 1299, compareAt: null,
    short: "More capacity for longer days.",
    description: "A generous-capacity bottle for travel, gym sessions and long days away from home. Designed around the same copper-colour finish and elegant VEYRA styling.",
    material: "Stainless steel (confirm grade with supplier before launch)", finish: "Copper-colour finish", capacity: "1 litre", care: "Hand-wash recommended until supplier care instructions are confirmed.", image: "images/bottle-1000.svg", tag: "LARGE CAPACITY"
  }
];
