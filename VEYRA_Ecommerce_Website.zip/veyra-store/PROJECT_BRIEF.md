# PROJECT BRIEF — VEYRA Ecommerce Website

## 1. Project Overview
Build a real, working ecommerce website for a luxury stainless steel water bottle brand. The website should be simple to use, mobile-friendly, and suitable for deployment as a static website.

- **Proposed brand name:** VEYRA
- **Brand positioning:** Luxury, premium, elegant, and modern
- **Target market:** India
- **Preferred domain:** Not finalised. `veyra.in` was suggested, but availability and trademark conflicts have not been checked.

## 2. Products and Customers
### Product range
Launch with three stainless steel water bottle products:
1. 250 ml stainless steel water bottle
2. 500 ml stainless steel water bottle
3. 1 litre stainless steel water bottle

- **Preferred bottle finish/colour:** Copper
- **Planned price range:** ₹700 or more per bottle
- Exact price for each size is not yet decided.
- Product images should be premium placeholders for now and replaceable with real product photos later.

### Target customers
A broad audience, including home, school, office, travel, and gym users.

## 3. Brand and Visual Design
- **Style:** Luxury and elegant
- **Brand palette:** Navy blue, white, and ice blue
- **Product finish:** Copper-coloured stainless steel bottles
- Use clean layouts, refined typography, strong product photography, and clear product information.
- Fonts and example/reference websites have not yet been specified; choose suitable premium fonts and styling during design.

## 4. Website Pages
Include these pages:
- Home
- Shop
- Product Details
- About
- Contact
- Cart
- Checkout

## 5. Required Features
- Offers and discount banners
- Customer reviews and ratings
- Product details and bottle specifications
- Shipping information, returns, and FAQs
- Order tracking
- WhatsApp support button
- Related product recommendations

## 6. Payments and Customer Contact
- **Payment methods planned:** Online payments and Cash on Delivery (COD)
- Online payments require a payment gateway account and configuration before live payments can be accepted.
- **Customer contact methods:** Phone and email
- Phone number and email address are not yet provided; use clearly marked placeholders until supplied.
- WhatsApp support is requested as a website feature, but the WhatsApp business number has not yet been provided.

## 7. Technical Requirements
- Use plain HTML, CSS, and vanilla JavaScript only.
- Do not use React, frameworks, npm, or build tools.
- The website should run by opening `index.html` in a browser.
- It should be suitable for static deployment using GitHub and a free static hosting provider.
- Prioritise a mobile-friendly layout.
- Any live checkout, payment processing, order tracking, or customer messaging features that depend on external services must be configured with the required accounts and credentials before they can operate fully.

## 8. Items to Confirm Before Launch
- Confirm the final brand name: VEYRA is the current proposed choice.
- Check availability of the chosen domain and any trademark conflicts.
- Confirm exact prices for each bottle size.
- Supply business phone number, email address, and WhatsApp number if WhatsApp support will be enabled.
- Confirm shipping charges, delivery estimates, return policy, and warranty details.
- Provide real product photos when available.
- Set up a payment gateway and define how orders and tracking will be managed.
- Confirm the actual bottle material, grade, and product specifications before publishing product claims.

## 9. Current Status
This brief reflects the discovery interview and the user's corrections: the bottles are **stainless steel, not plastic**, and the preferred finish is **copper**.

**Important:** This file is the approved planning brief only. Do not begin building the website until the user gives a separate instruction.
